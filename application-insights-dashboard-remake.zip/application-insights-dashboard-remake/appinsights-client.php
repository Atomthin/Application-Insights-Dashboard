<?php 
class AppInsights_Client {
	function __construct($config = null) {
		
	}
	
	
}
?>